//
//  Question.swift
//  RPJay - character manager
//
//  Created by Rafael Tomaz Prado on 04/04/17.
//  Copyright © 2017 Juliane Vianna. All rights reserved.
//

import Foundation

class Question{
    
    var question:String
    var aAnswer:String
    var bAnswer:String
    var cAnswer:String
    
    init(){
        self.question = String()
        self.aAnswer = String()
        self.bAnswer = String()
        self.cAnswer = String()
    }
}
