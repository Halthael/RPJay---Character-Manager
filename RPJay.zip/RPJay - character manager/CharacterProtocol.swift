//
//  CharacterProtocol.swift
//  RPJay - character manager
//
//  Created by Rafael Tomaz Prado on 03/04/17.
//  Copyright © 2017 Juliane Vianna. All rights reserved.
//

import Foundation

protocol CharacterProtocol {
    var newCharacter:Character?{ get set }
}
