//
//  ImageCell.swift
//  RPJay - character manager
//
//  Created by Rafael Tomaz Prado on 07/04/17.
//  Copyright © 2017 Juliane Vianna. All rights reserved.
//

import UIKit

class ImageCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
}
