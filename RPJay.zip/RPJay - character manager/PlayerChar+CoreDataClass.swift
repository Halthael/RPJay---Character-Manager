//
//  PlayerChar+CoreDataClass.swift
//  RPJay - character manager
//
//  Created by Rhullian Damião on 06/04/17.
//  Copyright © 2017 Juliane Vianna. All rights reserved.
//

import Foundation
import CoreData

@objc(PlayerChar)
public class PlayerChar: NSManagedObject {

}
